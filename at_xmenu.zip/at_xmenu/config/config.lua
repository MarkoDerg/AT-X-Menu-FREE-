MS = {}

MS.CheckPlayTime = true
MS.FiveBoxes = true
MS.FilePath = "C:/Users/Administrator/Desktop/MajorLife/txData/default/data/playersDB.json"
MS.RequiredPlayTime = 60 -- Mindestspielzeit in Minuten um jemanden zu fesseln
MS.Jobs = { -- Jobs welche die Mindestspielzeit ignorieren können
    ["police"] = true,
}

function Action(action)
    if action == "idcard" then 
        local target, distance = ESX.Game.GetClosestPlayer()

        if distance ~= -1 and distance < 3 then
            TriggerServerEvent('jsfour-idcard:open', GetPlayerServerId(PlayerId()), GetPlayerServerId(target))
        else
            Notify("Es gibt keinen Spieler in deiner Nähe.")
        end
    elseif action == "cuff" then
        local target, distance = ESX.Game.GetClosestPlayer()

        if distance ~= -1 and distance < 3 then
            ESX.TriggerServerCallback("ms_xmenu:getdata", function(time, job)
                if MS.CheckPlayTime then 
                    if MS.Jobs[job] then 
                        -- TriggerEvent("jobs_creator:actions:hardHandcuff")
                        TriggerEvent("jobs_creator:actions:softHandcuff")
                    else
                        if time > MS.RequiredPlayTime then 
                            -- TriggerEvent("jobs_creator:actions:hardHandcuff")
                            TriggerEvent("jobs_creator:actions:softHandcuff")
                        else
                            Notify("Du musst mindestens 1 Stunde gespielt haben, um jemanden zu fesseln.")
                        end
                    end
                else
                    -- TriggerEvent("jobs_creator:actions:hardHandcuff")
                    TriggerEvent("jobs_creator:actions:softHandcuff")
                end
            end)
        else
            Notify("Es gibt keinen Spieler in deiner Nähe.")
        end
    elseif action == "search" then
        local target, distance = ESX.Game.GetClosestPlayer()

        if distance ~= -1 and distance < 3 then
            ESX.TriggerServerCallback("ms_xmenu:getdata", function(time, job)
                if MS.CheckPlayTime then 
                    if MS.Jobs[job] then 
                        TriggerEvent("jobs_creator:actions:search")
                    else
                        if time > 60 then  -- 60 = 1 hour
                            TriggerEvent("jobs_creator:actions:search")
                        else
                            Notify("Du musst mindestens 1 Stunde gespielt haben, um jemanden zu durchsuchen.")
                        end
                    end
                else
                    TriggerEvent("jobs_creator:actions:search")
                end
            end)
        else
            Notify("Es gibt keinen Spieler in deiner Nähe.")
        end
    elseif action == "keys" then
        -- TriggerEvent("esx_carlock:toggleVehicleLock")
        exports["vehicles_keys"]:toggleClosestVehicleLock()
    elseif action == "engine" then
        local vehicle = GetVehiclePedIsIn(PlayerPedId(), false)

        if vehicle ~= nil and vehicle ~= 0 and GetPedInVehicleSeat(vehicle, 0) then
            if not GetIsVehicleEngineRunning(vehicle) then 
                Notify("Fahrzeugmotor Gestartet")
            else
                Notify("Fahrzeugmotor Gestoppt")
            end
            
            SetVehicleEngineOn(vehicle, (not GetIsVehicleEngineRunning(vehicle)), false, true)
        else
            Notify("Du musst in einem Fahrzeug sitzen, um den Motor zu starten.")
        end
    end 
end