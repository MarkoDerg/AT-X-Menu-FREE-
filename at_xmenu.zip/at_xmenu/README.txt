
-- Tuh Das In Dein carlock script (clientside)

RegisterNetEvent("esx_carlock:toggleVehicleLock")
AddEventHandler("esx_carlock:toggleVehicleLock", function()
    -- carlock code
end)