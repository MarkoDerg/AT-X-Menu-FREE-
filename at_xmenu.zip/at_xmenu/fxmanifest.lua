fx_version "cerulean"
games { "gta5" }
lua54 'yes'
author 'MarkoTkm'
description 'Das Beste Und Schönste X menu Auf Fivem (FREE). Anthrazit Service'
version '1.0.0'

client_scripts {
    "config/config.lua",
    "client/client.lua",
}

server_scripts {
    "config/config.lua",
    "server/server.lua",
}

ui_page "html/index.html"
files {
    "html/index.html",
    "html/assets/**/*.*",
}

escrow_ignore {
    "config/config.lua",
}