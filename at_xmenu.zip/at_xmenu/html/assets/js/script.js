window.addEventListener('message', function(event) {
    const item = event.data
    
    if (item.action == "OpenMenu") {
        if (item.state) {
            if (item.fiveboxes) {
                $(".main-container-first").show()
            } else {
                $(".main-container-second").show()
            }
        } else {
            if (item.fiveboxes) {
                $(".main-container-first").hide()
            } else {
                $(".main-container-second").hide()
            }
        }
    }
})

$(document).ready(function() {
    $(".mn-circ-hover-first").click(function() {
        Action("engine");
    }).hover(function() {
        $("#little-circ-ic").attr("src", "assets/images/engine-ic.svg");
    }, function() {
        $("#little-circ-ic").attr("src", "assets/images/empty.png");
    });

    $(".mn-circ-hover-second").click(function() {
        Action("keys");
    }).hover(function() {
        $("#little-circ-ic").attr("src", "assets/images/keys-ic.svg");
    }, function() {
        $("#little-circ-ic").attr("src", "assets/images/empty.png");
    });

    $(".mn-circ-hover-third").click(function() {
        Action("search");
    }).hover(function() {
        $("#little-circ-ic").attr("src", "assets/images/search-ic.svg");
    }, function() {
        $("#little-circ-ic").attr("src", "assets/images/empty.png");
    });

    $(".mn-circ-hover-four").click(function() {
        Action("cuff");
    }).hover(function() {
        $("#little-circ-ic").attr("src", "assets/images/handcuffs-ic.svg");
    }, function() {
        $("#little-circ-ic").attr("src", "assets/images/empty.png");
    });

    $(".mn-circ-hover-five").click(function() {
        Action("idcard");
    }).hover(function() {
        $("#little-circ-ic").attr("src", "assets/images/card-ic.svg");
    }, function() {
        $("#little-circ-ic").attr("src", "assets/images/empty.png");
    });


    $(".mn-sc-circ-hover-first").click(function() {
        Action("keys");
    }).hover(function() {
        $("#little-circ-sc-ic").attr("src", "assets/images/keys-ic.svg");
    }, function() {
        $("#little-circ-sc-ic").attr("src", "assets/images/empty.png");
    });

    $(".mn-sc-circ-hover-second").click(function() {
        Action("search");
    }).hover(function() {
        $("#little-circ-sc-ic").attr("src", "assets/images/search-ic.svg");
    }, function() {
        $("#little-circ-sc-ic").attr("src", "assets/images/empty.png");
    });

    $(".mn-sc-circ-hover-third").click(function() {
        Action("cuff");
    }).hover(function() {
        $("#little-circ-sc-ic").attr("src", "assets/images/handcuffs-ic.svg");
    }, function() {
        $("#little-circ-sc-ic").attr("src", "assets/images/empty.png");
    });

    $(".mn-sc-circ-hover-four").click(function() {
        Action("idcard");
    }).hover(function() {
        $("#little-circ-sc-ic").attr("src", "assets/images/card-ic.svg");
    }, function() {
        $("#little-circ-sc-ic").attr("src", "assets/images/empty.png");
    });
});

function Action(action) {
    $.post(`https://${GetParentResourceName()}/action`, JSON.stringify({
        action: action
    }));
}

document.onkeyup = function(event) {
    event = event || window.event;
    var keyCode = event.keyCode || event.which;

    if (keyCode === 88 || keyCode === 120) {
        $.post(`https://${GetParentResourceName()}/exit`);
    }
};